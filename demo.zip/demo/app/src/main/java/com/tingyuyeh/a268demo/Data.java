package com.tingyuyeh.a268demo;

public class Data {
    public String sender;
    public String msg;



}
