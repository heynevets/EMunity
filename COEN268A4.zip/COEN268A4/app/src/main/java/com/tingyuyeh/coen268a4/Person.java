package com.tingyuyeh.coen268a4;

public class Person {
    String _id = "";
    String _name;
    String _email;
    String _favourite;
    public Person(String name, String email, String favourite) {
        _name = name;
        _email = email;
        _favourite = favourite;
    }
}
